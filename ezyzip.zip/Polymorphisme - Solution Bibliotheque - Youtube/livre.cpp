/**
Tuto vidéo : https://youtu.be/9dR3oXW4C5I
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/
#include "livre.h"

Livre::Livre():Ouvrage()
{
    auteur="";
}

Livre::Livre(string titre,string date,bool exist,string auteur):Ouvrage( titre, date, exist)
{
    this->auteur=auteur;
}

void Livre::afficher()const
{
    Ouvrage::afficher();
    cout<<"l\auteur est : "<<auteur<<endl;
}
