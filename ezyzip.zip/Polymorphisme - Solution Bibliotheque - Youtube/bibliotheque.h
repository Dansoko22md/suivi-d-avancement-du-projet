/**
Tuto vidéo : https://youtu.be/9dR3oXW4C5I
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/
#ifndef BIBLIOTHEQUE_H
#define BIBLIOTHEQUE_H
#include "ouvrage.h"
#include "video.h"
#include "livre.h"
#include "abonne.h"
#include<string>
#include <iostream>
#include<vector>

using namespace std;

class Bibliotheque
{
    public:

        Bibliotheque(){};       //construteur par défaut
        ~Bibliotheque();
        Bibliotheque(const Bibliotheque&);
        Bibliotheque& operator=(const Bibliotheque &);
        bool ajouter(const Ouvrage &O);
        bool ajouter(const Livre &O);
        bool ajouter(const Video &O);
        vector<Ouvrage*>::iterator get_ouvrage(string titre);
        bool emprunter(string ,long);
        bool rendre(long id);
        bool ajouter(const Abonne &A);
        vector<Abonne>::iterator get_abonne(long id);

        void info();
    private:
        vector<Abonne>tabA;
        vector<Ouvrage*> tabOuv;


};

#endif // BIBLIOTHEQUE_H
