/**
Tuto vidéo : https://youtu.be/9dR3oXW4C5I
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/
#ifndef LIVRE_H
#define LIVRE_H
#include "ouvrage.h"

class Livre :public Ouvrage
{
    public:
        Livre();
        Livre(string,string,bool,string);
        void afficher()const;
        string get_auteur()const{return auteur;}
    private:
        string auteur;
};

#endif // LIVRE_H
