/**
Tuto vidéo : https://youtu.be/9dR3oXW4C5I
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/
#ifndef VIDEO_H
#define VIDEO_H
#include "ouvrage.h"

class Video :public Ouvrage
{
    public:
        Video();
        Video(string,string,bool,string,int);
        string get_editeur()const{return editeur;}
        int get_duree()const{return duree;}
        void afficher()const;
    private:
        string editeur;
        int duree;
};

#endif // VIDEO_H
