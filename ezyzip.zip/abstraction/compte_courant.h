/**
Tuto vidéo : https://youtu.be/aM_Tf6sUbto
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/


#ifndef COMPTE_COURANT_H_
#define COMPTE_COURANT_H_

#include "compte.h"

class CompteCourant:public Compte
{
    private:
        double seuil;
    public:
        CompteCourant(long = 0,double = 0, double = -500);
        ~CompteCourant(){}
        bool retirer(double );
        double get_seuil() const {return seuil;}
        void set_seuil(double s) {seuil = s;}
        void afficher()const;

};


#endif /* COMPTE_COURANT_H_ */
