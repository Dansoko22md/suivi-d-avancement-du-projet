/**
Tuto vid�o : https://youtu.be/9dR3oXW4C5I
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/

#include "ouvrage.h"
#include "video.h"
#include "livre.h"
#include "abonne.h"
#include "bibliotheque.h"

int main()
{
    Ouvrage O1("bonjour","12/08/1990",true);
    Video O2("but","12/06/2000",false,"bale",85);
    Livre O3("albou5ale2","08/08/2002",true,"alja7edh");
    Abonne A(759,"skandar",2070,"bonjour");

    Bibliotheque T;
    T.ajouter(O1);
    T.ajouter(O2);
    T.ajouter(O3);
    T.ajouter(A);

    T.info();
   Bibliotheque T2 (T); //ctor de copie
   Bibliotheque T3 ;//ctor par d�faut
   T3.ajouter(O2);

   T3 = T; //op�rateur =

/*
    Ouvrage *p1;

    p1 = new Ouvrage ("bonjour","12/08/1990",true);
    p1->afficher();
    delete p1;

    p1 = new  Video ("but","12/06/2000",false,"bale",85);
    p1->afficher();
    delete p1;

    p1 = new Livre ("albou5ale2","08/08/2002",true,"alja7edh");
    p1->afficher();
    delete p1;
*/
    return 0;
}
