

#include "compte.h"
#include<iostream>
using namespace std;

Compte::Compte(long r,double s):RIB(r),solde(s)
{

}


void Compte::deposer(double montant)
{
	solde+=montant;
}



void Compte::afficher() const
{
	cout<<"RIB: "<<RIB<<endl;
	cout<<"Solde: "<<solde<<endl;
}


Compte::~Compte(){}

