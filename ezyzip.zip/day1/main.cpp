
#include "compte.h"
#include "compte_courant.h"
#include "compte_epargne.h"

#include <iostream>
using namespace std;


int main() {
//	Compte C;
	CompteEpargne C1(20,250,5);
	CompteCourant C2(30,250);

    C1.afficher();
    C2.afficher();

    Compte *p = new CompteEpargne (20,250,5);
    p->afficher();
    delete p;
	return 0;
}
