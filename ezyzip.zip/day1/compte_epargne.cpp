/**
Tuto vid�o : https://youtu.be/aM_Tf6sUbto
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/

#include "compte_epargne.h"
#include<iostream>
using namespace std;


CompteEpargne::CompteEpargne(long num,double solde, double interet):Compte(num,solde), interet(interet)
{

}

bool CompteEpargne::retirer(double montant)
{
    bool b=false;
    if((solde-montant)>=30)
    {
        solde -= montant;
        b=true;
    }
    return b;
}


void CompteEpargne::afficher() const
{
    Compte::afficher();
    cout<<"Interet Annuel:"<<interet<<endl;
    cout<<"Montant + Interet Annuel:"<<get_solde_interet()<<endl;
}


double CompteEpargne::get_solde_interet() const
{
	return (solde*(1+interet));
}

bool CompteEpargne::set_interet(float x)
{
    if(x>=0 && x<=1) //cont�le de la validit� de la nouvelle valeur
    {
        interet = x;
        return true;
    }
    return false;
}
