/**
Tuto vid�o : https://youtu.be/aM_Tf6sUbto
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/


#ifndef COMPTE_EPARGNE_H_
#define COMPTE_EPARGNE_H_

#include "compte.h"


class CompteEpargne:public Compte
{
    private:
        float interet; //interet de 7% sera 0.07

    public:
        CompteEpargne(long =0,double =30, double =0);
        ~CompteEpargne(){}
        double get_solde_interet()const;
        float get_interet()const {return interet;}
        bool set_interet(float x);
        bool retirer(double );
        void afficher()const;
};


#endif /* COMPTE_EPARGNE_H_ */
