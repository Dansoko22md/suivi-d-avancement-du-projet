/**
Tuto vid�o : https://youtu.be/aM_Tf6sUbto
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/

#ifndef COMPTE_H_
#define COMPTE_H_


class Compte
{

  protected:
    long RIB;
    double solde;

  public:
    Compte(long num=0 ,double solde=0);
    virtual ~Compte();
    double get_solde()const {return solde;}
    long get_RIB()const{return RIB;}
    void set_RIB(long r){RIB = r;}
    virtual bool retirer(double) = 0;  //virtuelle pure
    void deposer(double);
    virtual void afficher() const;
};

#endif /* COMPTE_H_ */
