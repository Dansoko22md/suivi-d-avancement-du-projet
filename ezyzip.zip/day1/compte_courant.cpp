/**
Tuto vid�o : https://youtu.be/aM_Tf6sUbto
Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
*/


#include "compte_courant.h"
#include<iostream>
using namespace std;

CompteCourant::CompteCourant(long num, double solde, double seuil):Compte(num,solde), seuil(seuil)
{

}

bool CompteCourant::retirer(double montant)
{
    bool b=false;
    if((solde-montant)>=seuil)
    {
        solde -= montant;
        b=true;
    }
    return b;
}

void CompteCourant::afficher() const
{
    Compte::afficher();
    cout<<"Seuil mensuel:"<<seuil<<endl;
}
