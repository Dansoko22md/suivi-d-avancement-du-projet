//============================================================================
// Name        : main.cpp
// Author      :
// Version     :
// Copyright   : GPLv3
// Description : Apprendre C++
// Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
//============================================================================

#include <iostream>
using namespace std;
#include "Article.h"
#include "ArticleenSolde.h"
#include "Gestion.h"
int main() {
	Article T1("Stylo",12);
	ArticleEnSolde T2("PC",1200,10);


    Gestion G;
    G.ajouter(T1);
    G.ajouter(T2);
    G.afficher();


	return 0;
}




	//Article *p;
	//p=new ArticleEnSolde(B);

	//p->Afficher();

	//A=B;
	//A.Afficher();
	//B.Afficher();
