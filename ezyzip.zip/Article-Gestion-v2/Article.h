/*
 * Article.h
 *
 *      Author: alaya-zied
 * Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
 */

#ifndef ARTICLE_H_
#define ARTICLE_H_
#include<string>

using namespace std;

class Article
{
protected:
    string nom;
    double prix;

public:
    virtual double GetPrix() const
    {
        return prix;
    }
    void SetPrix(double prix)
    {
        this->prix=prix;
    }

    string GetNom() const
    {
        return nom;
    }

    virtual void afficher() const;
    Article(string nom="", double prix=0 );
    virtual ~Article(){}

};

#endif /* ARTICLE_H_ */
