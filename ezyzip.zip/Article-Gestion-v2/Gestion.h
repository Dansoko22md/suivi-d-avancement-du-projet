/*
 * Gestion.h
 *
 *      Author: alaya-zied
 */

#ifndef GESTION_H_
#define GESTION_H_

#include "Article.h"
#include "ArticleenSolde.h"
#include <vector>
using namespace std;

class Gestion {
	vector<Article*>tab;
public:
	Gestion();
	~Gestion();
	void ajouter(const Article& A);
	void ajouter(const ArticleEnSolde& A);
	void afficher();
	Gestion& operator=(const Gestion&);
	Gestion(const Gestion& G);
	int update_remise(string,int);
};

#endif /* GESTION_H_ */
