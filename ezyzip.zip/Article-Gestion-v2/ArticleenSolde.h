/*
 * ArticleenSolde.h
 *
 *      Author: alaya-zied
 * Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
 */

#ifndef ARTICLEENSOLDE_H_
#define ARTICLEENSOLDE_H_
#include "Article.h"
#include<string>

using namespace std;

class ArticleEnSolde:public Article
{
private:
    int remise;
public:
    void SetRemise(int remise)
    {
        this->remise=remise;
    }
    double GetPrix() const
    {
        return  (prix*(100-remise)/100);
    }
    double GetRemise() const
    {
        return  remise;
    }
    void afficher() const;

    //constructeur
    ArticleEnSolde(string nom="", double prix=0, int remise=0);
};

#endif /* ARTICLEENSOLDE_H_ */
