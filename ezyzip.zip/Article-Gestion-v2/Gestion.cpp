/*
 * Gestion.cpp
 *
 *      Author: alaya-zied
 * Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
 */

#include "Gestion.h"
#include <typeinfo>
#include <iostream>
using namespace std;

Gestion::Gestion()
{
    // TODO Auto-generated constructor stub

}


Gestion& Gestion::operator=(const Gestion& G)
{
    Article *p;
    if (this!=&G)
    {
        vector<Article*>::iterator j;
        for (j=tab.begin();j != tab.end();j++)
        {
            delete (*j);
        }
        tab.clear();

        vector<Article*>::const_iterator i;
        for (i=tab.begin();i != tab.end();i++)
        {
            if (typeid(**i)==typeid(Article))
            {
                p = new Article(**i);
            }
            else
            {
                p = new ArticleEnSolde (static_cast<const ArticleEnSolde&> (**i));
            }
            tab.push_back(p);
        }
    }
    return *this;
}

Gestion::Gestion(const Gestion& G)
{
    Article *p;
        vector<Article*>::const_iterator i;
        for (i=tab.begin();i != tab.end();i++)
        {
            if (typeid(**i)==typeid(Article))
            {
                p = new Article(**i);
            }
            else
            {
                p = new ArticleEnSolde (static_cast<const ArticleEnSolde&> (**i));
            }
            tab.push_back(p);
        }

}

void Gestion::ajouter(const Article& A)
{
    Article *p;
    p = new Article(A);
    tab.push_back(p);
}

void Gestion::ajouter(const ArticleEnSolde& A)
{
    ArticleEnSolde *p;
    if (A.GetRemise()!=0)
    {
        p = new ArticleEnSolde(A);
        tab.push_back(p);
    }
}

void Gestion::afficher()
{
    vector<Article*>::iterator i;
    for (i=tab.begin();i != tab.end();i++)
    {
        (*i)->afficher();  //(**i).afficher();
        cout<<endl;
    }
}


Gestion::~Gestion()
{
    vector<Article*>::iterator i;
    for (i=tab.begin();i != tab.end();i++)
    {
        delete (*i);
    }
}

int Gestion::update_remise(string nom,int remise)
{
    ArticleEnSolde *q;
    int nb = 0;
    vector<Article*>::iterator i;
    for (i=tab.begin();i != tab.end();i++)
    {
        if((typeid(**i) == typeid (ArticleEnSolde)) && (**i).GetNom()==nom)
        {
            q = (ArticleEnSolde *) (*i);
            (*q).SetRemise(remise);
            nb++;
        }
    }
    return nb;

}
