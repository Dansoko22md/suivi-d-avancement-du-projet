/*
 * Article.cpp
 *
 *      Author: alaya-zied
 * Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
 */


#include<iostream>
#include "Article.h"



Article::Article(string nom,double prix)
{
	this->nom=nom;
	this->prix=prix;
}

void Article::afficher() const
{
    cout << "Produit: "<< nom <<endl;
	cout << "Prix = " << prix<<endl;
}
