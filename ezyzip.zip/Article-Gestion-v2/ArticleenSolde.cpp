/*
 * ArticleenSolde.cpp
 *
 *      Author: alaya-zied
 * Chaine Youtube : https://www.youtube.com/playlist?list=PLNb3yMyDcSZ5Sl1Og26O5tL_RCHSjUmVZ
 */

#include "ArticleenSolde.h"
#include<iostream>

ArticleEnSolde::ArticleEnSolde(string nom, double prix, int remise):Article(nom, prix)
{
	this->remise=remise;
}

void ArticleEnSolde::afficher() const
{
	Article::afficher();
	cout << "La remise =" << remise << endl;
	cout << "Le prix apres remise =" <<GetPrix() << endl;
}
